import PySimpleGUI as sg

label_1 = sg.Text("Select files         ")
input_1 = sg.Input()
choose_files_button_1 = sg.FilesBrowse("Choose", key="files")

label_2 = sg.Text("Select destination")
input_2 = sg.Input()
choose_files_button_2 = sg.FolderBrowse("Choose", key="folder")

compress_button = sg.Button("Compress")

window = sg.Window("File Compressor",
                   layout=[[label_1, input_1, choose_files_button_1],
                           [label_2, input_2, choose_files_button_2],
                           [compress_button]])

while True:
    event, values = window.read()
    print(event)
    print(values)
    filepath = values["files"].split(";")
    folder = values["folder"]
# sg.WIN_CLOSED:
window.close()

"""
{0: 'C:/Users/steve/Desktop/CERTIFICATE_LANDING_PAGE_C47Q4QCKQVDJ.jpeg;C:/Users/steve/Desktop/CERTIFICATE_LANDING_PAGE_Q25KXYNUK2P6.jpeg;C:/Users/steve/AppData/Local/GitHubDesktop/GitHubDesktop.exe;C:/Users/steve/Desktop/New Text Document.txt', 
'files': 'C:/Users/steve/Desktop/CERTIFICATE_LANDING_PAGE_C47Q4QCKQVDJ.jpeg;
C:/Users/steve/Desktop/CERTIFICATE_LANDING_PAGE_Q25KXYNUK2P6.jpeg;
C:/Users/steve/AppData/Local/GitHubDesktop/GitHubDesktop.exe;
C:/Users/steve/Desktop/New Text Document.txt', 
1: 'C:/Users/steve/Desktop', 
'folder': 'C:/Users/steve/Desktop'}

"""
